
from flask import Flask, request, jsonify
from flask_cors import CORS
import pickle
import numpy as np

app = Flask(__name__)
CORS(app)

with open('groundwater_rf_model.pkl', 'rb') as f:
    model = pickle.load(f)

@app.route('/')
def home():
    return "🌊 Groundwater API is running!"

@app.route('/predict', methods=['POST'])
def predict():
    data = request.get_json()
    
    # Update keys based on your actual model
    features = [
        data['rainfall'],
        data['landuse'],
        data['population'],
        data['elevation']
    ]
    
    prediction = model.predict([features])[0]
    return jsonify({'prediction': prediction})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000)
